#!/bin/bash
# .platform/hooks/postdeploy/01_configure_domain.sh

echo "====== Iniciando configuración de dominio ======"

# Asegurar que los directorios importantes existan y tengan permisos adecuados
mkdir -p /var/app/current/app/static
mkdir -p /var/app/current/app/uploads
mkdir -p /var/app/current/app/temp_uploads
mkdir -p /var/app/current/flask_session

# Asignar permisos adecuados
chown -R webapp:webapp /var/app/current/app/static
chown -R webapp:webapp /var/app/current/app/uploads
chown -R webapp:webapp /var/app/current/app/temp_uploads
chown -R webapp:webapp /var/app/current/flask_session

chmod -R 755 /var/app/current/app/static
chmod -R 755 /var/app/current/app/uploads
chmod -R 755 /var/app/current/app/temp_uploads
chmod -R 755 /var/app/current/flask_session

# Comprobar la configuración de nginx
echo "====== Verificando configuración de nginx ======"
nginx -t

# Agregar configuración específica para aumentar el tiempo de respuesta
if [ -f "/etc/nginx/conf.d/elasticbeanstalk/00_application.conf" ]; then
    echo "====== Ajustando timeouts en nginx ======"
    sed -i 's/proxy_read_timeout 60;/proxy_read_timeout 300;/' /etc/nginx/conf.d/elasticbeanstalk/00_application.conf
    sed -i 's/proxy_send_timeout 60;/proxy_send_timeout 300;/' /etc/nginx/conf.d/elasticbeanstalk/00_application.conf
    sed -i 's/proxy_connect_timeout 60;/proxy_connect_timeout 300;/' /etc/nginx/conf.d/elasticbeanstalk/00_application.conf
fi

# Verificar que la aplicación responde
echo "====== Verificando que la aplicación responde ======"
curl -I http://localhost:8000/health

# Reiniciar nginx para aplicar todos los cambios
echo "====== Reiniciando nginx ======"
service nginx restart

echo "====== Configuración de dominio completada ======"