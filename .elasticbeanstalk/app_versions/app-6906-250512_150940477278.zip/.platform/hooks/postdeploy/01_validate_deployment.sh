#!/bin/bash
echo "Validating deployment..."

# Check if the application is responding
HEALTH_CHECK_URL="http://localhost/health"
MAX_RETRIES=5
RETRY_INTERVAL=5

for i in $(seq 1 $MAX_RETRIES); do
    echo "Attempt $i: Checking application health..."
    if curl -s -o /dev/null -w "%{http_code}" $HEALTH_CHECK_URL | grep -q "200"; then
        echo "Application is healthy!"
        exit 0
    else
        echo "Application is not healthy yet, waiting..."
        sleep $RETRY_INTERVAL
    fi
done

echo "Warning: Application health check didn't succeed within expected time"
# Don't fail the deployment, but log the warning
exit 0