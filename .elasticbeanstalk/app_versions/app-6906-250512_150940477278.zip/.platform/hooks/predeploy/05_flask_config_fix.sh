#!/bin/bash
set -e

source /var/app/venv/*/bin/activate
cd /var/app/staging

echo "Applying Flask configuration fixes..."

# Create a standalone health check application
cat > health_standalone.py << 'EOL'
from flask import Flask

app = Flask(__name__)

@app.route('/health', methods=['GET'])
def health_check():
    return 'OK', 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
EOL

# Update the Procfile to include the health check if needed
if ! grep -q "health:" Procfile; then
    echo "health: python health_standalone.py" >> Procfile
    echo "Added health check to Procfile"
fi

# Fix SERVER_NAME in run.py
if ! grep -q "SERVER_NAME" run.py; then
    cat > run.py.new << 'EOL'
from app import create_app

application = create_app()  # OJO: debe ser 'application', NO 'app'

# Allow requests from any host
application.config["SERVER_NAME"] = None

if __name__ == "__main__":
    application.run(host="0.0.0.0", port=5001)
EOL
    mv run.py.new run.py
    echo "Fixed run.py SERVER_NAME configuration"
fi

echo "Flask configuration fixes applied"