#!/bin/bash
# Check for problematic Nginx config files and remove them
echo "Checking for problematic Nginx configurations..."

# List of known problematic configs
PROBLEM_CONFIGS=(
    "/etc/nginx/conf.d/01_static.conf"
)

for config in "${PROBLEM_CONFIGS[@]}"; do
    if [ -f "$config" ]; then
        echo "Removing problematic config: $config"
        sudo rm -f "$config"
    fi
done

echo "Nginx configuration cleanup completed"