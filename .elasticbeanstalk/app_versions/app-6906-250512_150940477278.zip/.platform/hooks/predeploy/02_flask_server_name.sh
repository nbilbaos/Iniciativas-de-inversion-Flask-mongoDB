#!/bin/bash
source /var/app/venv/*/bin/activate
echo "Patching Flask app server name check..."
cd /var/app/staging/
cat > patch.py << 'EOPY'
import re

def patch_file(file_path):
    with open(file_path, 'r') as f:
        content = f.read()

    # Add SERVER_NAME config in app/__init__.py
    if file_path.endswith('app/__init__.py'):
        pattern = r"(app\.config\[\'PERMANENT_SESSION_LIFETIME\'\] = 1800.+?)"
        replacement = r"\1\n    app.config['SERVER_NAME'] = None  # Allow any server name"
        content = re.sub(pattern, replacement, content, flags=re.DOTALL)

    with open(file_path, 'w') as f:
        f.write(content)

patch_file('app/__init__.py')
print("Flask server name check patched")
EOPY

python patch.py
chmod +x .platform/hooks/predeploy/02_flask_server_name.sh
