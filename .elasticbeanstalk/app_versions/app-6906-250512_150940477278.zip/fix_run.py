with open('run.py', 'r') as f:
    content = f.read()

updated_content = content.replace(
    'application = create_app()',
    'application = create_app()  # This MUST be named "application" for Elastic Beanstalk\n\n# Set SERVER_NAME to None to accept any host header\napplication.config["SERVER_NAME"] = None'
)

with open('run.py', 'w') as f:
    f.write(updated_content)

print("Updated run.py to accept any server name")
