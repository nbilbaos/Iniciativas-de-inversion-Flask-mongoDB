#!/usr/bin/env python3
import re
import os


def patch_app_init():
    """Update app/__init__.py to fix server name issues"""
    init_path = os.path.join('app', '__init__.py')

    if not os.path.exists(init_path):
        print(f"Warning: {init_path} not found!")
        return

    with open(init_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Add SERVER_NAME configuration
    if "app.config['SERVER_NAME']" not in content:
        # Find a good place to insert the config - after other app.config settings
        session_config_pattern = r"(app\.config\['SESSION_COOKIE_SAMESITE'\] = 'Lax')"
        if re.search(session_config_pattern, content):
            modified_content = re.sub(
                session_config_pattern,
                r"\1\n    # Accept requests from any host\n    app.config['SERVER_NAME'] = None",
                content
            )

            # Save the modified content
            with open(init_path, 'w', encoding='utf-8') as f:
                f.write(modified_content)
            print(f"Updated {init_path} with SERVER_NAME = None")
        else:
            print(f"Warning: Couldn't find a place to add SERVER_NAME in {init_path}")
    else:
        print(f"SERVER_NAME already configured in {init_path}")


def fix_run_py():
    """Update run.py to ensure proper Elastic Beanstalk integration"""
    run_path = 'run.py'

    if not os.path.exists(run_path):
        print(f"Warning: {run_path} not found!")
        return

    with open(run_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Check if we need to update the application creation
    if "application.config[\"SERVER_NAME\"]" not in content:
        modified_content = content.replace(
            'application = create_app()',
            'application = create_app()  # Must be named "application" for Elastic Beanstalk\n\n'
            '# Allow requests from any host\n'
            'application.config["SERVER_NAME"] = None'
        )

        # Save the modified content
        with open(run_path, 'w', encoding='utf-8') as f:
            f.write(modified_content)
        print(f"Updated {run_path} with SERVER_NAME = None")
    else:
        print(f"SERVER_NAME already configured in {run_path}")


def enhance_health_endpoint():
    """Improve the health endpoint for Elastic Beanstalk"""
    health_path = os.path.join('app', 'health.py')

    if not os.path.exists(health_path):
        print(f"Warning: {health_path} not found!")
        return

    with open(health_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Check if the health endpoint needs enhancement
    if "@health_bp.route('/health'" in content:
        # Ensure the CSRF exemption is applied and the route is correct
        modified_content = content.replace(
            "@csrf.exempt\n@health_bp.route('/health', methods=['GET'])",
            "@csrf.exempt\n@health_bp.route('/health', methods=['GET'])\n@health_bp.route('/', methods=['GET'])"
        )

        # Save the modified content
        with open(health_path, 'w', encoding='utf-8') as f:
            f.write(modified_content)
        print(f"Enhanced health endpoint in {health_path}")
    else:
        print(f"Health endpoint not found in {health_path}")


def create_standalone_health():
    """Create a standalone health.py file that can run independently"""
    standalone_path = 'health_standalone.py'

    content = """
from flask import Flask

app = Flask(__name__)

@app.route('/health', methods=['GET'])
def health_check():
    return 'OK', 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
"""

    with open(standalone_path, 'w', encoding='utf-8') as f:
        f.write(content.strip())

    print(f"Created standalone health check at {standalone_path}")


if __name__ == "__main__":
    print("Applying Flask configuration fixes...")
    patch_app_init()
    fix_run_py()
    enhance_health_endpoint()
    create_standalone_health()
    print("Flask configuration fixed successfully!")