#!/bin/bash
# Script to fix the Elastic Beanstalk deployment issues

# 1. Fix the health check endpoint
cat > .platform/nginx/conf.d/health.conf << 'EOL'
location /health {
    proxy_pass http://127.0.0.1:8000/health;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
EOL

# 2. Fix static file configuration
if [ -f /etc/nginx/conf.d/01_static.conf ]; then
    sudo rm /etc/nginx/conf.d/01_static.conf
fi

cat > .platform/nginx/conf.d/static.conf << 'EOL'
location /static {
    alias /var/app/current/app/static;
    add_header Cache-Control "public, max-age=86400";
}
EOL

# 3. Create a server name configuration for the domain
cat > .platform/nginx/conf.d/server_name.conf << 'EOL'
server_name iniciativas.cl www.iniciativas.cl;
EOL

# 4. Update Flask app to accept any server name
cat > .platform/hooks/predeploy/02_flask_server_name.sh << 'EOL'
#!/bin/bash
source /var/app/venv/*/bin/activate
echo "Patching Flask app server name check..."
cd /var/app/staging/
cat > patch.py << 'EOPY'
import re

def patch_file(file_path):
    with open(file_path, 'r') as f:
        content = f.read()

    # Add SERVER_NAME config in app/__init__.py
    if file_path.endswith('app/__init__.py'):
        pattern = r"(app\.config\[\'PERMANENT_SESSION_LIFETIME\'\] = 1800.+?)"
        replacement = r"\1\n    app.config['SERVER_NAME'] = None  # Allow any server name"
        content = re.sub(pattern, replacement, content, flags=re.DOTALL)

    with open(file_path, 'w') as f:
        f.write(content)

patch_file('app/__init__.py')
print("Flask server name check patched")
EOPY

python patch.py
chmod +x .platform/hooks/predeploy/02_flask_server_name.sh
EOL

chmod +x .platform/hooks/predeploy/02_flask_server_name.sh

# Make the health check endpoint properly accessible
cat > patch_health.py << 'EOL'
import os

def fix_health_endpoint():
    with open('app/__init__.py', 'r') as f:
        init_content = f.read()

    # Update the health endpoint registration
    # Make sure the health endpoint is registered correctly and early in the process
    if 'app.register_blueprint(health_bp)' in init_content:
        modified_content = init_content.replace(
            'app.register_blueprint(health_bp)',
            'app.register_blueprint(health_bp, url_prefix="")'
        )

        with open('app/__init__.py', 'w') as f:
            f.write(modified_content)

        print("Fixed health endpoint registration")
    else:
        print("Health endpoint registration not found")

fix_health_endpoint()
EOL

python patch_health.py

# Fix the main run.py file to ensure it works with EB
cat > fix_run.py << 'EOL'
with open('run.py', 'r') as f:
    content = f.read()

updated_content = content.replace(
    'application = create_app()',
    'application = create_app()  # This MUST be named "application" for Elastic Beanstalk\n\n# Set SERVER_NAME to None to accept any host header\napplication.config["SERVER_NAME"] = None'
)

with open('run.py', 'w') as f:
    f.write(updated_content)

print("Updated run.py to accept any server name")
EOL

python fix_run.py

echo "All fixes applied successfully!"