import os

def fix_health_endpoint():
    with open('app/__init__.py', 'r') as f:
        init_content = f.read()

    # Update the health endpoint registration
    # Make sure the health endpoint is registered correctly and early in the process
    if 'app.register_blueprint(health_bp)' in init_content:
        modified_content = init_content.replace(
            'app.register_blueprint(health_bp)',
            'app.register_blueprint(health_bp, url_prefix="")'
        )

        with open('app/__init__.py', 'w') as f:
            f.write(modified_content)

        print("Fixed health endpoint registration")
    else:
        print("Health endpoint registration not found")

fix_health_endpoint()
