from app import create_app


application = create_app()  # OJO: debe ser 'application', NO 'app'

if __name__ == "__main__":
    application.run(host="0.0.0.0", port=5001)
